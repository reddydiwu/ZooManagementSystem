package com.zoo.parking;

public interface IParking {
	void parking();
void stop();
void buyTicket();
}
