package com.zoo.emp;
import com.zoo.emp.Employee;
public class HealthSupport extends Employee{

	public static void emp() {
	Employee hs=new HealthSupport();
	hs.setName("Reddy");
	hs.setAge(23);
	hs.setContact(9700775313L);
	hs.setAddress("1-231 nagari puttur");
	hs.setDesignation("Doctor");

	System.out.println(hs.getName());
	System.out.println(hs.getAge());
	System.out.println(hs.getContact());
	System.out.println(hs.getAddress());
	System.out.println(hs.getDesignation());
	}

	public void work()
	{
		System.out.println("Doctor gives treatment");
	}

}
